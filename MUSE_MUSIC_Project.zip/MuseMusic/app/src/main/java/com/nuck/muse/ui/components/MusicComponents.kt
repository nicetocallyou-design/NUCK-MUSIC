package com.nuck.muse.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nuck.muse.data.MusicCollection
import com.nuck.muse.data.Track
import com.nuck.muse.ui.theme.MuseAccent
import com.nuck.muse.ui.theme.MuseBackground
import com.nuck.muse.ui.theme.MuseSurface
import com.nuck.muse.ui.theme.MuseSurfaceElevated
import com.nuck.muse.ui.theme.MuseTextPrimary
import com.nuck.muse.ui.theme.MuseTextSecondary

private val artworkPalettes = listOf(
    listOf(Color(0xFF142B52), Color(0xFFEA6680)),
    listOf(Color(0xFF9A4C32), Color(0xFFFFC36D)),
    listOf(Color(0xFF244C46), Color(0xFFB6C982)),
    listOf(Color(0xFF38316A), Color(0xFF8FA6E8)),
    listOf(Color(0xFF6C315B), Color(0xFFE78B9A)),
    listOf(Color(0xFF26363C), Color(0xFF9AB8B0))
)

@Composable
fun AlbumArt(
    artworkId: Int,
    modifier: Modifier = Modifier,
    showMonogram: Boolean = true
) {
    val palette = artworkPalettes[artworkId.mod(artworkPalettes.size)]
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(palette))
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height
            drawCircle(
                color = Color.White.copy(alpha = 0.12f),
                radius = size.minDimension * 0.43f,
                center = Offset(w * 0.78f, h * 0.23f)
            )
            drawCircle(
                color = Color.Black.copy(alpha = 0.12f),
                radius = size.minDimension * 0.33f,
                center = Offset(w * 0.22f, h * 0.82f),
                style = Stroke(width = size.minDimension * 0.08f)
            )
            val path = Path().apply {
                moveTo(w * 0.06f, h * 0.78f)
                cubicTo(w * 0.30f, h * 0.48f, w * 0.58f, h * 0.92f, w * 0.98f, h * 0.40f)
            }
            drawPath(path, Color.White.copy(alpha = 0.16f), style = Stroke(width = size.minDimension * 0.012f))
        }
        if (showMonogram) {
            Text(
                text = "M",
                modifier = Modifier.align(Alignment.Center),
                color = Color.White.copy(alpha = 0.82f),
                fontSize = 46.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-4).sp
            )
        }
    }
}

@Composable
fun SectionHeading(
    title: String,
    action: String? = null,
    onAction: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 26.dp, bottom = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MuseTextPrimary)
        if (action != null && onAction != null) {
            Text(
                text = action,
                color = MuseAccent,
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.clickable(onClick = onAction)
            )
        }
    }
}

@Composable
fun CollectionCard(collection: MusicCollection, onClick: () -> Unit, compact: Boolean = false) {
    val cardWidth = if (compact) 124.dp else 156.dp
    Column(
        modifier = Modifier
            .width(cardWidth)
            .clickable(onClick = onClick)
    ) {
        AlbumArt(
            artworkId = collection.artworkId,
            modifier = Modifier
                .fillMaxWidth()
                .height(cardWidth)
        )
        Spacer(Modifier.height(9.dp))
        Text(
            text = collection.title,
            color = MuseTextPrimary,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = collection.subtitle,
            color = MuseTextSecondary,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun TrackRow(
    track: Track,
    isLiked: Boolean,
    onClick: () -> Unit,
    onToggleLike: () -> Unit,
    showDuration: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumArt(
            artworkId = track.artworkId,
            modifier = Modifier.size(54.dp),
            showMonogram = false
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(start = 12.dp, end = 8.dp)
        ) {
            Text(
                text = track.title,
                color = MuseTextPrimary,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = if (track.isExplicit) "E  •  ${track.artist}" else track.artist,
                color = MuseTextSecondary,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (showDuration) {
            Text(track.duration, color = MuseTextSecondary, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.width(8.dp))
        }
        IconButton(onClick = onToggleLike, modifier = Modifier.size(40.dp)) {
            Icon(
                imageVector = if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = if (isLiked) "Remove from favorites" else "Add to favorites",
                tint = if (isLiked) MuseAccent else MuseTextSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
        IconButton(onClick = onClick, modifier = Modifier.size(34.dp)) {
            Icon(Icons.Rounded.MoreHoriz, contentDescription = "More", tint = MuseTextSecondary)
        }
    }
}

@Composable
fun MiniPlayer(
    track: Track,
    isPlaying: Boolean,
    onOpen: () -> Unit,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(MuseSurfaceElevated)
            .clickable(onClick = onOpen)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(62.dp)
                .padding(horizontal = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArt(track.artworkId, Modifier.size(44.dp), showMonogram = false)
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(track.title, color = MuseTextPrimary, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(track.artist, color = MuseTextSecondary, style = MaterialTheme.typography.labelSmall, maxLines = 1)
            }
            IconButton(onClick = onTogglePlay, modifier = Modifier.size(42.dp)) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = MuseTextPrimary,
                    modifier = Modifier.size(25.dp)
                )
            }
            IconButton(onClick = onNext, modifier = Modifier.size(38.dp)) {
                Icon(Icons.Rounded.SkipNext, contentDescription = "Next track", tint = MuseTextPrimary)
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(MuseSurface)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.34f)
                    .height(2.dp)
                    .background(MuseAccent)
            )
        }
    }
}
