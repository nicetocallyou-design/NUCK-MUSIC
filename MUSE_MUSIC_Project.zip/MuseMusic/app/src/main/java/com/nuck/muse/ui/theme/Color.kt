package com.nuck.muse.ui.theme

import androidx.compose.ui.graphics.Color

val MuseBackground = Color(0xFF0B0C0F)
val MuseSurface = Color(0xFF15171C)
val MuseSurfaceElevated = Color(0xFF20232A)
val MuseAccent = Color(0xFFFF5268)
val MuseTextPrimary = Color(0xFFF6F6F7)
val MuseTextSecondary = Color(0xFF9A9DA7)
val MuseDivider = Color(0xFF2A2D34)
