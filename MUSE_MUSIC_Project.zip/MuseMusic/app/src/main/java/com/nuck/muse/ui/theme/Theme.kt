package com.nuck.muse.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val MuseDarkColorScheme = darkColorScheme(
    primary = MuseAccent,
    onPrimary = MuseTextPrimary,
    background = MuseBackground,
    onBackground = MuseTextPrimary,
    surface = MuseSurface,
    onSurface = MuseTextPrimary,
    surfaceVariant = MuseSurfaceElevated,
    onSurfaceVariant = MuseTextSecondary,
    outline = MuseDivider
)

@Composable
fun MuseTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MuseDarkColorScheme,
        content = content
    )
}
