package com.nuck.muse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nuck.muse.data.MusicCollection
import com.nuck.muse.data.SampleMusic
import com.nuck.muse.data.Track
import com.nuck.muse.ui.components.AlbumArt
import com.nuck.muse.ui.components.CollectionCard
import com.nuck.muse.ui.components.SectionHeading
import com.nuck.muse.ui.components.TrackRow
import com.nuck.muse.ui.theme.MuseAccent
import com.nuck.muse.ui.theme.MuseBackground
import com.nuck.muse.ui.theme.MuseTextPrimary
import com.nuck.muse.ui.theme.MuseTextSecondary

@Composable
fun ListenScreen(
    likedTrackIds: Set<String>,
    onTrackClick: (Track) -> Unit,
    onToggleLike: (Track) -> Unit,
    onBrowse: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MuseBackground),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 24.dp)
    ) {
        item {
            Text("YOUR SOUND, YOUR SPACE", color = MuseAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text(
                text = "Listen now",
                color = MuseTextPrimary,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 5.dp)
            )
            Text("A little something for every moment.", color = MuseTextSecondary, fontSize = 14.sp, modifier = Modifier.padding(top = 5.dp, bottom = 20.dp))
        }
        item {
            FeaturedMixCard(onClick = { onTrackClick(SampleMusic.tracks.first()) })
        }
        item {
            SectionHeading("Made for you", "Explore", onBrowse)
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(SampleMusic.collections) { collection ->
                    CollectionCard(collection = collection, onClick = {
                        onTrackClick(collection.tracks.firstOrNull() ?: SampleMusic.tracks.first())
                    })
                }
            }
        }
        item {
            SectionHeading("Recently played", "See all", onBrowse)
        }
        items(SampleMusic.tracks.take(5)) { track ->
            TrackRow(
                track = track,
                isLiked = track.id in likedTrackIds,
                onClick = { onTrackClick(track) },
                onToggleLike = { onToggleLike(track) }
            )
        }
        item {
            SectionHeading("Editor's picks", "More", onBrowse)
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(SampleMusic.collections.reversed()) { collection ->
                    CollectionCard(collection = collection, onClick = {
                        onTrackClick(collection.tracks.firstOrNull() ?: SampleMusic.tracks.first())
                    }, compact = true)
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun FeaturedMixCard(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(206.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF1C2948), Color(0xFF79445E), Color(0xFFE16A70))
                )
            )
            .clickable(onClick = onClick)
            .padding(20.dp)
    ) {
        Column(modifier = Modifier.align(Alignment.CenterStart)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Text("  YOUR DAILY MIX", color = Color.White.copy(alpha = 0.86f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            }
            Text(
                "Find your\nnext favorite.",
                color = Color.White,
                fontSize = 27.sp,
                lineHeight = 31.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 12.dp)
            )
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 13.dp)) {
                Text("PLAY MIX", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                Icon(Icons.Rounded.ArrowForward, contentDescription = null, tint = Color.White, modifier = Modifier.padding(start = 6.dp).size(15.dp))
            }
        }
        AlbumArt(
            artworkId = 0,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .size(126.dp)
                .padding(2.dp)
        )
    }
}
