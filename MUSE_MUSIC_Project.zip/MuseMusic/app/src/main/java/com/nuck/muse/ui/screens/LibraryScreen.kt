package com.nuck.muse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nuck.muse.data.SampleMusic
import com.nuck.muse.data.Track
import com.nuck.muse.ui.components.SectionHeading
import com.nuck.muse.ui.components.TrackRow
import com.nuck.muse.ui.theme.MuseAccent
import com.nuck.muse.ui.theme.MuseBackground
import com.nuck.muse.ui.theme.MuseSurface
import com.nuck.muse.ui.theme.MuseTextPrimary
import com.nuck.muse.ui.theme.MuseTextSecondary

@Composable
fun LibraryScreen(
    likedTrackIds: Set<String>,
    onTrackClick: (Track) -> Unit,
    onToggleLike: (Track) -> Unit
) {
    val favoriteTracks = SampleMusic.tracks.filter { it.id in likedTrackIds }
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(MuseBackground),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 24.dp)
    ) {
        item {
            Text("YOUR COLLECTION", color = MuseAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("Library", color = MuseTextPrimary, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp, bottom = 20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LibraryShortcut("Playlists", "4", Icons.Rounded.MusicNote, Modifier.weight(1f))
                LibraryShortcut("Favorites", favoriteTracks.size.toString(), Icons.Rounded.Favorite, Modifier.weight(1f))
            }
            SectionHeading("Recently added")
        }
        items(SampleMusic.collections.take(3)) { collection ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
                com.nuck.muse.ui.components.AlbumArt(collection.artworkId, Modifier.size(54.dp), showMonogram = false)
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(collection.title, color = MuseTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Playlist • ${collection.subtitle}", color = MuseTextSecondary, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
        item {
            SectionHeading("Favorite songs")
            if (favoriteTracks.isEmpty()) {
                Text("Songs you favorite will appear here.", color = MuseTextSecondary, fontSize = 13.sp, modifier = Modifier.padding(vertical = 12.dp))
            }
        }
        items(favoriteTracks) { track ->
            TrackRow(
                track = track,
                isLiked = true,
                onClick = { onTrackClick(track) },
                onToggleLike = { onToggleLike(track) }
            )
        }
        item { Spacer(Modifier.height(14.dp)) }
    }
}

@Composable
private fun LibraryShortcut(title: String, count: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(15.dp))
            .background(MuseSurface)
            .padding(horizontal = 13.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MuseAccent, modifier = Modifier.size(22.dp))
        Column(Modifier.padding(start = 10.dp)) {
            Text(title, color = MuseTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text("$count items", color = MuseTextSecondary, fontSize = 10.sp)
        }
    }
}
