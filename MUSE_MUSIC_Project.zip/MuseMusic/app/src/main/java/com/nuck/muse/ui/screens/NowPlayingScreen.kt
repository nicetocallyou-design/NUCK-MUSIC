package com.nuck.muse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Airplay
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nuck.muse.data.Track
import com.nuck.muse.ui.components.AlbumArt
import com.nuck.muse.ui.theme.MuseAccent
import com.nuck.muse.ui.theme.MuseBackground
import com.nuck.muse.ui.theme.MuseTextPrimary
import com.nuck.muse.ui.theme.MuseTextSecondary

@Composable
fun NowPlayingScreen(
    track: Track,
    isPlaying: Boolean,
    isLiked: Boolean,
    onClose: () -> Unit,
    onTogglePlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onToggleLike: () -> Unit
) {
    var progress by remember(track.id) { mutableFloatStateOf(0.32f) }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF2A2639), MuseBackground.copy(alpha = 0.98f), MuseBackground)
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 22.dp)
    ) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                modifier = Modifier.fillMaxWidth().height(52.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = "Close player", tint = MuseTextPrimary)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("NOW PLAYING", color = MuseTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
                    Text("From your library", color = MuseTextPrimary, fontSize = 11.sp)
                }
                IconButton(onClick = onToggleLike) {
                    Icon(
                        if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (isLiked) MuseAccent else MuseTextPrimary
                    )
                }
            }
            Spacer(Modifier.weight(0.8f))
            AlbumArt(
                artworkId = track.artworkId,
                modifier = Modifier.fillMaxWidth().aspectRatio(1f).padding(horizontal = 8.dp)
            )
            Spacer(Modifier.weight(0.8f))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(track.title, color = MuseTextPrimary, fontSize = 23.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track.artist, color = MuseTextSecondary, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
                }
                IconButton(onClick = onToggleLike) {
                    Icon(
                        if (isLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (isLiked) MuseAccent else MuseTextSecondary,
                        modifier = Modifier.size(23.dp)
                    )
                }
            }
            Slider(
                value = progress,
                onValueChange = { progress = it },
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                colors = SliderDefaults.colors(
                    thumbColor = MuseTextPrimary,
                    activeTrackColor = MuseTextPrimary,
                    inactiveTrackColor = MuseTextSecondary.copy(alpha = 0.35f)
                )
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("1:18", color = MuseTextSecondary, fontSize = 10.sp)
                Text(track.duration, color = MuseTextSecondary, fontSize = 10.sp)
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 15.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onPrevious, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, contentDescription = "Previous", tint = MuseTextPrimary, modifier = Modifier.size(31.dp))
                }
                IconButton(onClick = onTogglePlay, modifier = Modifier.size(72.dp)) {
                    Box(
                        modifier = Modifier.fillMaxSize().background(MuseTextPrimary, androidx.compose.foundation.shape.CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = MuseBackground,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }
                IconButton(onClick = onNext, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Next", tint = MuseTextPrimary, modifier = Modifier.size(31.dp))
                }
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Icon(Icons.Rounded.Airplay, contentDescription = "Audio output", tint = MuseTextSecondary, modifier = Modifier.size(20.dp))
                Icon(Icons.Rounded.QueueMusic, contentDescription = "Queue", tint = MuseTextSecondary, modifier = Modifier.size(20.dp))
            }
        }
    }
}
