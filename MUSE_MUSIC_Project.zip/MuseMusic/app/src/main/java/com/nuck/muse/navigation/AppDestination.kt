package com.nuck.muse.navigation

enum class AppTab(val label: String) {
    Listen("Listen"),
    Browse("Browse"),
    Radio("Radio"),
    Library("Library"),
    Search("Search")
}
