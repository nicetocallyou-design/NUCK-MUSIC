package com.nuck.muse.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.nuck.muse.data.SampleMusic
import com.nuck.muse.data.Track
import com.nuck.muse.ui.components.MiniPlayer
import com.nuck.muse.ui.components.MusicBottomBar
import com.nuck.muse.ui.screens.BrowseScreen
import com.nuck.muse.ui.screens.LibraryScreen
import com.nuck.muse.ui.screens.ListenScreen
import com.nuck.muse.ui.screens.NowPlayingScreen
import com.nuck.muse.ui.screens.RadioScreen
import com.nuck.muse.ui.screens.SearchScreen
import com.nuck.muse.ui.theme.MuseBackground

@Composable
fun MuseApp() {
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.Listen) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var currentTrack by remember { mutableStateOf(SampleMusic.tracks.first()) }
    var isPlaying by rememberSaveable { mutableStateOf(false) }
    var likedTrackIds by remember { mutableStateOf(setOf("t1", "t3")) }

    fun selectTrack(track: Track) {
        currentTrack = track
        isPlaying = true
    }

    fun toggleLike(track: Track) {
        likedTrackIds = if (track.id in likedTrackIds) {
            likedTrackIds - track.id
        } else {
            likedTrackIds + track.id
        }
    }

    fun playNext() {
        val tracks = SampleMusic.tracks
        val currentIndex = tracks.indexOfFirst { it.id == currentTrack.id }.coerceAtLeast(0)
        currentTrack = tracks[(currentIndex + 1) % tracks.size]
        isPlaying = true
    }

    fun playPrevious() {
        val tracks = SampleMusic.tracks
        val currentIndex = tracks.indexOfFirst { it.id == currentTrack.id }.coerceAtLeast(0)
        currentTrack = tracks[(currentIndex - 1 + tracks.size) % tracks.size]
        isPlaying = true
    }

    BackHandler(enabled = showPlayer) {
        showPlayer = false
    }

    if (showPlayer) {
        NowPlayingScreen(
            track = currentTrack,
            isPlaying = isPlaying,
            isLiked = currentTrack.id in likedTrackIds,
            onClose = { showPlayer = false },
            onTogglePlay = { isPlaying = !isPlaying },
            onPrevious = ::playPrevious,
            onNext = ::playNext,
            onToggleLike = { toggleLike(currentTrack) }
        )
    } else {
        Scaffold(
            containerColor = MuseBackground,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                Column(Modifier.navigationBarsPadding()) {
                    MiniPlayer(
                        track = currentTrack,
                        isPlaying = isPlaying,
                        onOpen = { showPlayer = true },
                        onTogglePlay = { isPlaying = !isPlaying },
                        onNext = ::playNext
                    )
                    MusicBottomBar(
                        selectedTab = selectedTab,
                        onSelect = { selectedTab = it }
                    )
                }
            }
        ) { innerPadding ->
            Box(Modifier.fillMaxSize().padding(innerPadding)) {
                when (selectedTab) {
                    AppTab.Listen -> ListenScreen(
                        likedTrackIds = likedTrackIds,
                        onTrackClick = ::selectTrack,
                        onToggleLike = ::toggleLike,
                        onBrowse = { selectedTab = AppTab.Browse }
                    )
                    AppTab.Browse -> BrowseScreen(
                        likedTrackIds = likedTrackIds,
                        onTrackClick = ::selectTrack,
                        onToggleLike = ::toggleLike,
                        onGoToSearch = { selectedTab = AppTab.Search }
                    )
                    AppTab.Radio -> RadioScreen(onPlayStation = ::selectTrack)
                    AppTab.Library -> LibraryScreen(
                        likedTrackIds = likedTrackIds,
                        onTrackClick = ::selectTrack,
                        onToggleLike = ::toggleLike
                    )
                    AppTab.Search -> SearchScreen(
                        likedTrackIds = likedTrackIds,
                        onTrackClick = ::selectTrack,
                        onToggleLike = ::toggleLike
                    )
                }
            }
        }
    }
}
