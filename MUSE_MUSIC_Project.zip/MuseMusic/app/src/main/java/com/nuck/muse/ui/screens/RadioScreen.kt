package com.nuck.muse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nuck.muse.data.MusicCollection
import com.nuck.muse.data.SampleMusic
import com.nuck.muse.data.Track
import com.nuck.muse.ui.components.AlbumArt
import com.nuck.muse.ui.components.SectionHeading
import com.nuck.muse.ui.theme.MuseAccent
import com.nuck.muse.ui.theme.MuseBackground
import com.nuck.muse.ui.theme.MuseTextPrimary
import com.nuck.muse.ui.theme.MuseTextSecondary

@Composable
fun RadioScreen(onPlayStation: (Track) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(MuseBackground),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 24.dp)
    ) {
        item {
            Text("LIVE & CURATED", color = MuseAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("Radio", color = MuseTextPrimary, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp))
            Text("A station for every side of you.", color = MuseTextSecondary, fontSize = 14.sp, modifier = Modifier.padding(top = 5.dp))
            Spacer(Modifier.height(20.dp))
            FeaturedRadioCard(onClick = { onPlayStation(SampleMusic.tracks[4]) })
            SectionHeading("Stations picked for you")
        }
        items(SampleMusic.stations) { station ->
            RadioStationRow(station) {
                onPlayStation(station.tracks.firstOrNull() ?: SampleMusic.tracks.first())
            }
        }
        item {
            SectionHeading("Always on", "All stations")
            Text("Continuous music, thoughtful curation, and new discoveries — whenever you need them.", color = MuseTextSecondary, fontSize = 13.sp, lineHeight = 20.sp)
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun FeaturedRadioCard(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(190.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF282A52), Color(0xFF8E436B), Color(0xFFE36C68))))
            .clickable(onClick = onClick)
            .padding(20.dp)
    ) {
        Column(Modifier.align(Alignment.CenterStart)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = Color.White, modifier = Modifier.size(17.dp))
                Text("  LIVE RADIO", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            }
            Text("The MUSE\nBroadcast", color = Color.White, fontSize = 28.sp, lineHeight = 31.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
            Text("MUSIC WITHOUT THE NOISE", color = Color.White.copy(alpha = 0.8f), fontSize = 9.sp, letterSpacing = 1.sp, modifier = Modifier.padding(top = 8.dp))
        }
        Icon(Icons.Rounded.PlayArrow, contentDescription = "Play radio", tint = Color.White, modifier = Modifier.align(Alignment.BottomEnd).size(42.dp))
    }
}

@Composable
private fun RadioStationRow(station: MusicCollection, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumArt(station.artworkId, Modifier.size(66.dp), showMonogram = false)
        Column(Modifier.weight(1f).padding(horizontal = 13.dp)) {
            Text(station.title, color = MuseTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(station.subtitle, color = MuseTextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
        }
        Icon(Icons.Rounded.PlayArrow, contentDescription = "Play ${station.title}", tint = MuseAccent, modifier = Modifier.size(28.dp))
    }
}
