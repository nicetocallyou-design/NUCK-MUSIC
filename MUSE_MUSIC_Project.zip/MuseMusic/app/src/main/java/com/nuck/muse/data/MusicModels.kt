package com.nuck.muse.data

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val duration: String,
    val artworkId: Int,
    val isExplicit: Boolean = false
)

data class MusicCollection(
    val id: String,
    val title: String,
    val subtitle: String,
    val artworkId: Int,
    val tracks: List<Track> = emptyList()
)
