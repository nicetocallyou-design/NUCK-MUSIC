package com.nuck.muse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nuck.muse.data.SampleMusic
import com.nuck.muse.data.Track
import com.nuck.muse.ui.components.CollectionCard
import com.nuck.muse.ui.components.SectionHeading
import com.nuck.muse.ui.components.TrackRow
import com.nuck.muse.ui.theme.MuseAccent
import com.nuck.muse.ui.theme.MuseBackground
import com.nuck.muse.ui.theme.MuseSurface
import com.nuck.muse.ui.theme.MuseTextPrimary
import com.nuck.muse.ui.theme.MuseTextSecondary

@Composable
fun BrowseScreen(
    likedTrackIds: Set<String>,
    onTrackClick: (Track) -> Unit,
    onToggleLike: (Track) -> Unit,
    onGoToSearch: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(MuseBackground),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 24.dp)
    ) {
        item {
            Text("DISCOVER", color = MuseAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("Browse", color = MuseTextPrimary, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
            OutlinedTextField(
                value = "",
                onValueChange = {},
                modifier = Modifier.fillMaxWidth().clickable(onClick = onGoToSearch),
                enabled = false,
                placeholder = { Text("Artists, songs, albums", color = MuseTextSecondary) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = MuseTextSecondary) },
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    disabledTextColor = MuseTextPrimary,
                    disabledBorderColor = MuseSurface,
                    disabledContainerColor = MuseSurface,
                    disabledPlaceholderColor = MuseTextSecondary,
                    disabledLeadingIconColor = MuseTextSecondary
                ),
                singleLine = true
            )
        }
        item {
            SectionHeading("Explore by mood")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(listOf("Focus", "Chill", "Energy", "Romance", "Sleep")) { mood ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(MuseSurface)
                            .clickable(onClick = onGoToSearch)
                            .padding(horizontal = 17.dp, vertical = 11.dp)
                    ) {
                        Text(mood, color = MuseTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        item {
            SectionHeading("New and noteworthy", "See all", onGoToSearch)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(SampleMusic.collections) { collection ->
                    CollectionCard(collection, onClick = { onTrackClick(collection.tracks.firstOrNull() ?: SampleMusic.tracks.first()) })
                }
            }
        }
        item {
            SectionHeading("Top songs", "View charts", onGoToSearch)
        }
        items(SampleMusic.tracks.take(4)) { track ->
            TrackRow(
                track = track,
                isLiked = track.id in likedTrackIds,
                onClick = { onTrackClick(track) },
                onToggleLike = { onToggleLike(track) }
            )
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}
