package com.nuck.muse.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nuck.muse.data.SampleMusic
import com.nuck.muse.data.Track
import com.nuck.muse.ui.components.SectionHeading
import com.nuck.muse.ui.components.TrackRow
import com.nuck.muse.ui.theme.MuseAccent
import com.nuck.muse.ui.theme.MuseBackground
import com.nuck.muse.ui.theme.MuseSurface
import com.nuck.muse.ui.theme.MuseTextPrimary
import com.nuck.muse.ui.theme.MuseTextSecondary

@Composable
fun SearchScreen(
    likedTrackIds: Set<String>,
    onTrackClick: (Track) -> Unit,
    onToggleLike: (Track) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val results = SampleMusic.tracks.filter {
        it.title.contains(query, ignoreCase = true) || it.artist.contains(query, ignoreCase = true) || it.album.contains(query, ignoreCase = true)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(MuseBackground),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 24.dp)
    ) {
        item {
            Text("FIND YOUR SOUND", color = MuseAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("Search", color = MuseTextPrimary, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp, bottom = 18.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Songs, artists, albums", color = MuseTextSecondary) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = MuseTextSecondary) },
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = MuseTextPrimary,
                    unfocusedTextColor = MuseTextPrimary,
                    focusedBorderColor = MuseAccent,
                    unfocusedBorderColor = MuseSurface,
                    focusedContainerColor = MuseSurface,
                    unfocusedContainerColor = MuseSurface,
                    cursorColor = MuseAccent
                ),
                singleLine = true
            )
            if (query.isBlank()) {
                SectionHeading("Trending searches")
            } else {
                SectionHeading("Results")
            }
        }
        if (query.isBlank()) {
            items(listOf("Indie pop", "Late night drive", "Electronic", "M83", "Chill beats")) { term ->
                Text(
                    text = term,
                    color = MuseTextPrimary,
                    fontSize = 14.sp,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 13.dp)
                )
            }
        } else if (results.isEmpty()) {
            item {
                Text("No matches yet. Try another song or artist.", color = MuseTextSecondary, fontSize = 13.sp, modifier = Modifier.padding(vertical = 20.dp))
            }
        } else {
            items(results) { track ->
                TrackRow(
                    track = track,
                    isLiked = track.id in likedTrackIds,
                    onClick = { onTrackClick(track) },
                    onToggleLike = { onToggleLike(track) }
                )
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}
