package com.nuck.muse.data

object SampleMusic {
    val tracks = listOf(
        Track("t1", "Midnight City", "M83", "Hurry Up, We're Dreaming", "4:03", 0),
        Track("t2", "The Less I Know the Better", "Tame Impala", "Currents", "3:36", 1),
        Track("t3", "Sweet Disposition", "The Temper Trap", "Conditions", "3:54", 2),
        Track("t4", "Sunset Lover", "Petit Biscuit", "Presence", "3:57", 3),
        Track("t5", "Tadow", "Masego, FKJ", "Lady Lady", "5:02", 4),
        Track("t6", "Intro", "The xx", "xx", "2:07", 5),
        Track("t7", "Space Song", "Beach House", "Depression Cherry", "5:20", 2),
        Track("t8", "A Walk", "Tycho", "Dive", "5:16", 3)
    )

    val collections = listOf(
        MusicCollection("c1", "Late Night Focus", "A softer side of electronic", 0, tracks.take(4)),
        MusicCollection("c2", "Indie Essentials", "Songs worth keeping", 1, tracks.drop(2).take(4)),
        MusicCollection("c3", "Sunday Slowdown", "Take the long way home", 2, tracks.takeLast(4)),
        MusicCollection("c4", "Electronic Horizons", "New sounds, open skies", 3, tracks.reversed().take(4))
    )

    val stations = listOf(
        MusicCollection("r1", "MUSE ONE", "The sound of now", 4, tracks),
        MusicCollection("r2", "After Hours", "Downtempo • Ambient • Chill", 5, tracks),
        MusicCollection("r3", "Indie Frequency", "Alternative without borders", 1, tracks)
    )
}
